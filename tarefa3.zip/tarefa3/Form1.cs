﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tarefa3
{
    public partial class FrmQuadrado : Form
    {
        public FrmQuadrado()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float numero = float.Parse(txtNumero.Text);
            float resultado;

            resultado = numero * numero;

            MessageBox.Show("O Quadrado é: " + resultado);
        }
    }
}
