﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fcalculadoradoisnumeros
{
    public partial class FrmCalculadora : Form
    {
        public FrmCalculadora()
        {
            InitializeComponent();
        }

        private void btnMais_Click(object sender, EventArgs e)
        {
            float varN1 = float.Parse(txtN1.Text);
            float varN2 = float.Parse(txtN2.Text);
            float resultado;

            //soma;
            resultado = varN1 + varN2;
            MessageBox.Show("Soma: " + resultado);

        }

        private void btnMenos_Click(object sender, EventArgs e)
        {
            float varN1 = float.Parse(txtN1.Text);
            float varN2 = float.Parse(txtN2.Text);
            float resultado;

            //subtração;
            resultado = varN1 - varN2;
            MessageBox.Show("Menos: " + resultado);
        }

        private void btnVezes_Click(object sender, EventArgs e)
        {
            float varN1 = float.Parse(txtN1.Text);
            float varN2 = float.Parse(txtN2.Text);
            float resultado;

            //multiplicação;
            resultado = varN1 * varN2;
            MessageBox.Show("Multiplicação: " + resultado);
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            float varN1 = float.Parse(txtN1.Text);
            float varN2 = float.Parse(txtN2.Text);
            float resultado;

            //divisão;
            resultado = varN1 / varN2;
            MessageBox.Show("Divisão: " + resultado);
        }
    }
}